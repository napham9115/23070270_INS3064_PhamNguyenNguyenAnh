<?php
/**
 * INS3064 — Session 09 Homework: Robust Calculator
 * Name:       [Your Name]
 * Student ID: [Your Student ID]
 * Date:       2026-11-10
 *
 * Single-file calculator demonstrating custom exceptions, graceful error
 * handling, file-based error logging, and session-based calculation history.
 */

error_reporting(E_ALL);
date_default_timezone_set('Asia/Ho_Chi_Minh');
session_start();

/* ---------------- Custom exception classes ---------------- */

class DivisionByZeroException extends Exception
{
}

class InvalidOperatorException extends Exception
{
}

class InvalidInputException extends Exception
{
}

/* ---------------- Constants & helpers ---------------- */

const OPERATORS = ['+', '-', '*', '/', '%', '**'];
const LOG_FILE = __DIR__ . '/calculator_errors.log';

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function logError(Throwable $e, string $input): void
{
    $line = sprintf(
        '[%s] %s: %s | Input: "%s" | IP: %s%s',
        date('Y-m-d H:i:s'),
        get_class($e),
        $e->getMessage(),
        $input,
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        PHP_EOL
    );
    file_put_contents(LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

function formatResult(int|float $result, string $operator): string
{
    if ($operator === '/') {
        return number_format($result, 4, '.', '');
    }
    if (is_float($result) && abs($result) < PHP_INT_MAX && floor($result) === $result) {
        return (string) (int) $result;
    }
    return (string) $result;
}

/* ---------------- Request handling ---------------- */

$num1 = '';
$num2 = '';
$operator = '+';
$successMessage = '';
$errorMessage = '';
$warningMessage = '';

if (!isset($_SESSION['history']) || !is_array($_SESSION['history'])) {
    $_SESSION['history'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $num1 = trim((string) ($_POST['num1'] ?? ''));
    $num2 = trim((string) ($_POST['num2'] ?? ''));
    $operator = (string) ($_POST['operator'] ?? '');

    if (isset($_POST['clear_history'])) {
        $_SESSION['history'] = [];
        $warningMessage = 'Calculation history cleared.';
    } else {
        $rawInput = $num1 . ' ' . $operator . ' ' . $num2;

        try {
            // Validate input first: fail fast on the first problem found.
            if (!is_numeric($num1)) {
                throw new InvalidInputException(
                    'The first number is not numeric. Please enter a valid number, e.g. 12 or 3.5.'
                );
            }
            if (!is_numeric($num2)) {
                throw new InvalidInputException(
                    'The second number is not numeric. Please enter a valid number, e.g. 12 or 3.5.'
                );
            }

            $a = $num1 + 0;
            $b = $num2 + 0;
            if (is_infinite($a) || is_infinite($b)) {
                throw new InvalidInputException(
                    'A number is too large to represent. Please use smaller values.'
                );
            }

            if (!in_array($operator, OPERATORS, true)) {
                throw new InvalidOperatorException(
                    'The operator "' . $operator . '" is not supported. Please choose +, -, *, /, % or **.'
                );
            }

            if (($operator === '/' || $operator === '%') && $b == 0) {
                throw new DivisionByZeroException(
                    'Cannot divide by zero or take modulo by zero. Please change the second number.'
                );
            }
            if ($operator === '**' && $a == 0 && $b < 0) {
                throw new DivisionByZeroException(
                    'Zero cannot be raised to a negative power because that would divide by zero.'
                );
            }

            $result = match ($operator) {
                '+' => $a + $b,
                '-' => $a - $b,
                '*' => $a * $b,
                '/' => $a / $b,
                '%' => fmod($a, $b),
                '**' => $a ** $b,
            };

            if (is_infinite($result) || is_nan($result)) {
                throw new OverflowException(
                    'The result is not a finite number (overflow or invalid operation). Please try smaller or different values.'
                );
            }

            $formattedResult = formatResult($result, $operator);
            $expression = $a . ' ' . $operator . ' ' . $b;
            $successMessage = $expression . ' = ' . $formattedResult;

            $_SESSION['history'][] = [
                'expression' => $expression,
                'result' => $formattedResult,
                'timestamp' => date('Y-m-d H:i:s'),
            ];
        } catch (InvalidInputException $e) {
            logError($e, $rawInput);
            $errorMessage = $e->getMessage();
        } catch (InvalidOperatorException $e) {
            logError($e, $rawInput);
            $errorMessage = $e->getMessage();
        } catch (DivisionByZeroException $e) {
            logError($e, $rawInput);
            $errorMessage = $e->getMessage();
        } catch (OverflowException $e) {
            logError($e, $rawInput);
            $errorMessage = $e->getMessage();
        } catch (Throwable $e) {
            logError($e, $rawInput);
            $errorMessage = 'An unexpected error occurred. Please check your input and try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Robust Calculator — INS3064 Session 09</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
            background: #f0f2f5; margin: 0; padding: 24px 16px; color: #212529;
        }
        .container { max-width: 760px; margin: 0 auto; }
        .card {
            background: #fff; border-radius: 10px; padding: 24px;
            box-shadow: 0 1px 4px rgba(0, 0, 0, .12); margin-bottom: 24px;
        }
        h1 { font-size: 1.5rem; margin: 0 0 4px; }
        h2 { font-size: 1.15rem; margin: 0 0 12px; }
        .subtitle { color: #6c757d; margin: 0 0 20px; font-size: .95rem; }
        .form-row { display: flex; gap: 12px; flex-wrap: wrap; }
        .field { flex: 1; min-width: 140px; display: flex; flex-direction: column; }
        .field-operator { flex: 0 0 120px; min-width: 110px; }
        label { font-weight: 600; font-size: .9rem; margin-bottom: 6px; }
        input, select {
            padding: 10px; border: 1px solid #ced4da; border-radius: 6px;
            font-size: 1rem; width: 100%; background: #fff;
        }
        input:focus, select:focus { outline: 2px solid rgba(13, 110, 253, .25); border-color: #0d6efd; }
        .buttons { display: flex; gap: 12px; margin-top: 18px; flex-wrap: wrap; }
        button {
            padding: 10px 20px; border: none; border-radius: 6px;
            font-size: 1rem; cursor: pointer;
        }
        .btn-primary { background: #0d6efd; color: #fff; }
        .btn-primary:hover { background: #0b5ed7; }
        .btn-secondary { background: #fff; color: #c62828; border: 1px solid #c62828; }
        .btn-secondary:hover { background: #fdecea; }
        .box {
            padding: 14px 16px; border-radius: 6px; border: 1px solid;
            margin-top: 20px; font-size: 1.05rem;
        }
        .box-success { background: #e8f5e9; border-color: #2e7d32; color: #1b5e20; }
        .box-error { background: #fdecea; border-color: #c62828; color: #b71c1c; }
        .box-warning { background: #fff8e1; border-color: #f9a825; color: #7a5c00; }
        .expression { font-size: 1.25rem; font-weight: 700; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: .95rem; }
        th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid #e9ecef; }
        th { background: #f8f9fa; }
        tbody tr:nth-child(even) { background: #fbfcfd; }
        .empty, .note { color: #6c757d; }
        .note { font-size: .85rem; margin: 16px 0 0; }
        @media (max-width: 520px) {
            .field-operator { flex: 1 1 100%; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>Robust Calculator</h1>
        <p class="subtitle">INS3064 · Session 09 — Exception handling, error logging &amp; session history</p>

        <form method="post" action="calculator.php">
            <div class="form-row">
                <div class="field">
                    <label for="num1">First number</label>
                    <input type="text" id="num1" name="num1" inputmode="decimal"
                           value="<?= escapeHtml($num1) ?>" placeholder="e.g. 10">
                </div>
                <div class="field field-operator">
                    <label for="operator">Operator</label>
                    <select id="operator" name="operator">
                        <?php foreach (OPERATORS as $op): ?>
                            <option value="<?= escapeHtml($op) ?>" <?= $op === $operator ? 'selected' : '' ?>>
                                <?= escapeHtml($op) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field">
                    <label for="num2">Second number</label>
                    <input type="text" id="num2" name="num2" inputmode="decimal"
                           value="<?= escapeHtml($num2) ?>" placeholder="e.g. 3">
                </div>
            </div>
            <div class="buttons">
                <button type="submit" class="btn-primary">Calculate</button>
                <button type="submit" name="clear_history" value="1" class="btn-secondary">Clear History</button>
            </div>
        </form>

        <?php if ($successMessage !== ''): ?>
            <div class="box box-success"><span class="expression"><?= escapeHtml($successMessage) ?></span></div>
        <?php endif; ?>
        <?php if ($errorMessage !== ''): ?>
            <div class="box box-error"><strong>Error:</strong> <?= escapeHtml($errorMessage) ?></div>
        <?php endif; ?>
        <?php if ($warningMessage !== ''): ?>
            <div class="box box-warning"><?= escapeHtml($warningMessage) ?></div>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>Calculation History</h2>
        <?php if (empty($_SESSION['history'])): ?>
            <p class="empty">No calculations yet. Successful calculations will appear here (most recent first).</p>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                    <tr><th>#</th><th>Expression</th><th>Result</th><th>Timestamp</th></tr>
                    </thead>
                    <tbody>
                    <?php foreach (array_reverse($_SESSION['history']) as $i => $record): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= escapeHtml($record['expression']) ?></td>
                            <td><?= escapeHtml($record['result']) ?></td>
                            <td><?= escapeHtml($record['timestamp']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        <p class="note">Errors are logged to <code>calculator_errors.log</code> on the server, which is not publicly accessible.</p>
    </div>
</div>
</body>
</html>