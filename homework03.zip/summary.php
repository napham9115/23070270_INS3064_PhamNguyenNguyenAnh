<?php
session_start();

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_over'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: register.php');
    exit;
}

if (
    !isset($_SESSION['registration'], $_SESSION['survey'])
    || !is_array($_SESSION['registration'])
    || !is_array($_SESSION['survey'])
) {
    header('Location: register.php');
    exit;
}

$registration = $_SESSION['registration'];
$survey = $_SESSION['survey'];
$interests = is_array($survey['interests'] ?? null) ? $survey['interests'] : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Summary | INS3064</title>
    <style>
        :root { font-family: Arial, sans-serif; color: #20312e; background: #f2f6f4; }
        * { box-sizing: border-box; }
        body { margin: 0; padding: 36px 16px; }
        main { width: min(100%, 720px); margin: 0 auto; }
        .eyebrow { margin: 0 0 8px; color: #39776b; font-size: .78rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
        h1 { margin: 0; color: #174f45; font-size: 2rem; }
        .intro { margin: 10px 0 24px; color: #5d6d68; line-height: 1.55; }
        .panel { padding: 26px; border: 1px solid #d7e3df; border-radius: 8px; background: #fff; box-shadow: 0 12px 32px #183d3210; }
        .progress { display: flex; gap: 8px; margin-bottom: 22px; color: #6a7975; font-size: .84rem; }
        .progress span { padding: 7px 11px; border: 1px solid #d9e2df; border-radius: 4px; }
        .progress .active { border-color: #24695b; background: #e8f3ef; color: #174f45; font-weight: 700; }
        .welcome { margin: 0 0 22px; padding: 16px; border-left: 4px solid #2c806e; background: #eef7f3; color: #174f45; font-size: 1.05rem; }
        h2 { margin: 24px 0 10px; color: #174f45; font-size: 1.05rem; }
        dl { margin: 0; }
        .detail { display: grid; grid-template-columns: minmax(130px, 1fr) 2fr; gap: 12px; padding: 12px 0; border-bottom: 1px solid #e5ece9; }
        .detail dt { color: #5d6d68; }
        .detail dd { margin: 0; overflow-wrap: anywhere; font-weight: 700; }
        .interest-list { display: flex; flex-wrap: wrap; gap: 8px; padding: 0; list-style: none; }
        .interest-list li { padding: 8px 10px; border: 1px solid #c9ded6; border-radius: 4px; background: #f1f8f5; color: #205c4e; font-size: .9rem; }
        button { min-height: 44px; margin-top: 24px; padding: 0 18px; border: 1px solid #175b4e; border-radius: 4px; background: #fff; color: #175b4e; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #e8f3ef; }
        @media (max-width: 520px) { body { padding: 24px 12px; } .panel { padding: 19px; } h1 { font-size: 1.65rem; } .detail { grid-template-columns: 1fr; gap: 4px; } }
    </style>
</head>
<body>
    <main>
        <p class="eyebrow">INS3064 · Session 03</p>
        <h1>Registration complete</h1>
        <p class="intro">Your registration and survey responses are together below.</p>
        <div class="panel">
            <div class="progress" aria-label="Form progress">
                <span>01 · Register</span><span>02 · Survey</span><span class="active">03 · Summary</span>
            </div>
            <p class="welcome">Thank you, <?php echo escapeHtml((string) ($registration['name'] ?? '')); ?>. Your response has been recorded.</p>

            <h2>Registration</h2>
            <dl>
                <div class="detail"><dt>Full Name</dt><dd><?php echo escapeHtml((string) ($registration['name'] ?? '')); ?></dd></div>
                <div class="detail"><dt>Email</dt><dd><?php echo escapeHtml((string) ($registration['email'] ?? '')); ?></dd></div>
                <div class="detail"><dt>Age</dt><dd><?php echo escapeHtml((string) ($registration['age'] ?? '')); ?></dd></div>
                <div class="detail"><dt>Gender</dt><dd><?php echo escapeHtml((string) ($registration['gender'] ?? '')); ?></dd></div>
            </dl>

            <h2>Survey responses</h2>
            <dl>
                <div class="detail"><dt>Favorite Language</dt><dd><?php echo escapeHtml((string) ($survey['language'] ?? '')); ?></dd></div>
                <div class="detail"><dt>Experience Level</dt><dd><?php echo escapeHtml((string) ($survey['experience'] ?? '')); ?></dd></div>
            </dl>
            <h2>Interests</h2>
            <ul class="interest-list">
                <?php foreach ($interests as $interest): ?>
                    <li><?php echo escapeHtml((string) $interest); ?></li>
                <?php endforeach; ?>
            </ul>

            <form action="summary.php" method="post">
                <button type="submit" name="start_over" value="1">Start Over</button>
            </form>
        </div>
    </main>
</body>
</html>
