<?php
session_start();

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$errors = [];
$values = [
    'name' => '',
    'email' => '',
    'age' => '',
    'gender' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (array_keys($values) as $field) {
        $submittedValue = $_POST[$field] ?? '';
        $values[$field] = is_string($submittedValue) ? trim($submittedValue) : '';
    }

    $passwordValue = $_POST['password'] ?? '';
    $password = is_string($passwordValue) ? $passwordValue : '';
    $confirmValue = $_POST['confirm_password'] ?? '';
    $confirmPassword = is_string($confirmValue) ? $confirmValue : '';

    if ($values['name'] === '') {
        $errors['name'] = 'Please enter your full name.';
    }

    if ($values['email'] === '') {
        $errors['email'] = 'Please enter your email address.';
    } elseif (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }

    $passwordLength = preg_match_all('/./us', $password);
    if ($passwordLength === false || $passwordLength < 6) {
        $errors['password'] = 'Password must contain at least 6 characters.';
    }

    if ($confirmPassword !== $password) {
        $errors['confirm_password'] = 'The passwords do not match.';
    }

    $age = filter_var($values['age'], FILTER_VALIDATE_INT);
    if ($values['age'] === '' || $age === false || $age < 10 || $age > 100) {
        $errors['age'] = 'Age must be a whole number from 10 to 100.';
    }

    $allowedGenders = ['Male', 'Female', 'Other'];
    if (!in_array($values['gender'], $allowedGenders, true)) {
        $errors['gender'] = 'Please select a gender.';
    }

    if ($errors === []) {
        $_SESSION['registration'] = [
            'name' => $values['name'],
            'email' => $values['email'],
            'age' => $age,
            'gender' => $values['gender'],
        ];

        unset($_SESSION['survey']);
        header('Location: survey.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration | INS3064</title>
    <style>
        :root { font-family: Arial, sans-serif; color: #20312e; background: #f2f6f4; }
        * { box-sizing: border-box; }
        body { margin: 0; padding: 36px 16px; }
        main { width: min(100%, 680px); margin: 0 auto; }
        .eyebrow { margin: 0 0 8px; color: #39776b; font-size: .78rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
        h1 { margin: 0; color: #174f45; font-size: 2rem; }
        .intro { margin: 10px 0 24px; color: #5d6d68; line-height: 1.55; }
        .panel { padding: 26px; border: 1px solid #d7e3df; border-radius: 8px; background: #fff; box-shadow: 0 12px 32px #183d3210; }
        .progress { display: flex; gap: 8px; margin-bottom: 22px; color: #6a7975; font-size: .84rem; }
        .progress span { padding: 7px 11px; border: 1px solid #d9e2df; border-radius: 4px; }
        .progress .active { border-color: #24695b; background: #e8f3ef; color: #174f45; font-weight: 700; }
        .field { margin-bottom: 17px; }
        label, legend { display: block; margin-bottom: 7px; font-size: .93rem; font-weight: 700; }
        input[type="text"], input[type="email"], input[type="password"], input[type="number"] { width: 100%; min-height: 42px; padding: 9px 11px; border: 1px solid #bdcbc6; border-radius: 4px; background: #fff; color: #20312e; font: inherit; }
        input:focus { outline: 3px solid #a8d5c7; border-color: #24695b; }
        fieldset { margin: 0; padding: 0; border: 0; }
        .choices { display: flex; flex-wrap: wrap; gap: 10px 20px; }
        .choices label { display: inline-flex; align-items: center; gap: 7px; margin: 0; font-weight: 400; }
        .choices input { accent-color: #24695b; }
        .error { display: block; margin-top: 6px; color: #b42318; font-size: .86rem; }
        .has-error input { border-color: #b42318; }
        button { min-height: 44px; padding: 0 18px; border: 0; border-radius: 4px; background: #175b4e; color: #fff; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #10483e; }
        @media (max-width: 520px) { body { padding: 24px 12px; } .panel { padding: 19px; } h1 { font-size: 1.65rem; } }
    </style>
</head>
<body>
    <main>
        <p class="eyebrow">INS3064 · Session 03</p>
        <h1>Create your registration</h1>
        <p class="intro">Enter your details to continue to the programming survey.</p>
        <div class="panel">
            <div class="progress" aria-label="Form progress">
                <span class="active">01 · Register</span><span>02 · Survey</span><span>03 · Summary</span>
            </div>
            <form action="register.php" method="post" novalidate>
                <div class="field <?php echo isset($errors['name']) ? 'has-error' : ''; ?>">
                    <label for="name">Full Name</label>
                    <input id="name" name="name" type="text" value="<?php echo escapeHtml($values['name']); ?>" autocomplete="name" required aria-invalid="<?php echo isset($errors['name']) ? 'true' : 'false'; ?>" aria-describedby="name-error">
                    <?php if (isset($errors['name'])): ?><span class="error" id="name-error"><?php echo escapeHtml($errors['name']); ?></span><?php endif; ?>
                </div>
                <div class="field <?php echo isset($errors['email']) ? 'has-error' : ''; ?>">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="email" value="<?php echo escapeHtml($values['email']); ?>" autocomplete="email" required aria-invalid="<?php echo isset($errors['email']) ? 'true' : 'false'; ?>" aria-describedby="email-error">
                    <?php if (isset($errors['email'])): ?><span class="error" id="email-error"><?php echo escapeHtml($errors['email']); ?></span><?php endif; ?>
                </div>
                <div class="field <?php echo isset($errors['password']) ? 'has-error' : ''; ?>">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" autocomplete="new-password" minlength="6" required aria-invalid="<?php echo isset($errors['password']) ? 'true' : 'false'; ?>" aria-describedby="password-error">
                    <?php if (isset($errors['password'])): ?><span class="error" id="password-error"><?php echo escapeHtml($errors['password']); ?></span><?php endif; ?>
                </div>
                <div class="field <?php echo isset($errors['confirm_password']) ? 'has-error' : ''; ?>">
                    <label for="confirm_password">Confirm Password</label>
                    <input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" minlength="6" required aria-invalid="<?php echo isset($errors['confirm_password']) ? 'true' : 'false'; ?>" aria-describedby="confirm-password-error">
                    <?php if (isset($errors['confirm_password'])): ?><span class="error" id="confirm-password-error"><?php echo escapeHtml($errors['confirm_password']); ?></span><?php endif; ?>
                </div>
                <div class="field <?php echo isset($errors['age']) ? 'has-error' : ''; ?>">
                    <label for="age">Age</label>
                    <input id="age" name="age" type="number" min="10" max="100" step="1" value="<?php echo escapeHtml($values['age']); ?>" required aria-invalid="<?php echo isset($errors['age']) ? 'true' : 'false'; ?>" aria-describedby="age-error">
                    <?php if (isset($errors['age'])): ?><span class="error" id="age-error"><?php echo escapeHtml($errors['age']); ?></span><?php endif; ?>
                </div>
                <fieldset class="field">
                    <legend>Gender</legend>
                    <div class="choices">
                        <?php foreach (['Male', 'Female', 'Other'] as $genderOption): ?>
                            <label><input type="radio" name="gender" value="<?php echo escapeHtml($genderOption); ?>" <?php echo $values['gender'] === $genderOption ? 'checked' : ''; ?> required> <?php echo escapeHtml($genderOption); ?></label>
                        <?php endforeach; ?>
                    </div>
                    <?php if (isset($errors['gender'])): ?><span class="error" id="gender-error"><?php echo escapeHtml($errors['gender']); ?></span><?php endif; ?>
                </fieldset>
                <button type="submit">Continue to survey</button>
            </form>
        </div>
    </main>
</body>
</html>
