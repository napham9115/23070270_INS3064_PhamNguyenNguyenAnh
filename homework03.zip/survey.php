<?php
session_start();

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

if (!isset($_SESSION['registration']) || !is_array($_SESSION['registration'])) {
    header('Location: register.php');
    exit;
}

$languages = ['PHP', 'JavaScript', 'Python', 'Java', 'C++', 'Other'];
$experiences = ['Beginner', 'Intermediate', 'Advanced'];
$interestOptions = ['Web Development', 'Mobile Apps', 'Data Science', 'Cybersecurity', 'AI/ML', 'Game Development'];
$errors = [];
$values = [
    'language' => $_SESSION['survey']['language'] ?? '',
    'experience' => $_SESSION['survey']['experience'] ?? '',
    'interests' => $_SESSION['survey']['interests'] ?? [],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $languageValue = $_POST['language'] ?? '';
    $values['language'] = is_string($languageValue) ? $languageValue : '';
    $experienceValue = $_POST['experience'] ?? '';
    $values['experience'] = is_string($experienceValue) ? $experienceValue : '';
    $submittedInterests = $_POST['interests'] ?? [];
    if (!is_array($submittedInterests)) {
        $submittedInterests = [];
    }
    $submittedInterests = array_values(array_filter($submittedInterests, 'is_string'));
    $values['interests'] = array_values(array_intersect($interestOptions, $submittedInterests));

    if (!in_array($values['language'], $languages, true)) {
        $errors['language'] = 'Please choose a programming language.';
    }

    if (!in_array($values['experience'], $experiences, true)) {
        $errors['experience'] = 'Please select your experience level.';
    }

    if ($values['interests'] === []) {
        $errors['interests'] = 'Select at least one interest.';
    }

    if ($errors === []) {
        $_SESSION['survey'] = $values;
        header('Location: summary.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Programming Survey | INS3064</title>
    <style>
        :root { font-family: Arial, sans-serif; color: #20312e; background: #f2f6f4; }
        * { box-sizing: border-box; }
        body { margin: 0; padding: 36px 16px; }
        main { width: min(100%, 680px); margin: 0 auto; }
        .eyebrow { margin: 0 0 8px; color: #39776b; font-size: .78rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
        h1 { margin: 0; color: #174f45; font-size: 2rem; }
        .intro { margin: 10px 0 24px; color: #5d6d68; line-height: 1.55; }
        .panel { padding: 26px; border: 1px solid #d7e3df; border-radius: 8px; background: #fff; box-shadow: 0 12px 32px #183d3210; }
        .progress { display: flex; gap: 8px; margin-bottom: 22px; color: #6a7975; font-size: .84rem; }
        .progress span { padding: 7px 11px; border: 1px solid #d9e2df; border-radius: 4px; }
        .progress .active { border-color: #24695b; background: #e8f3ef; color: #174f45; font-weight: 700; }
        .field { margin: 0 0 21px; }
        label, legend { display: block; margin-bottom: 9px; font-size: .95rem; font-weight: 700; }
        select { width: 100%; min-height: 43px; padding: 9px 11px; border: 1px solid #bdcbc6; border-radius: 4px; background: #fff; color: #20312e; font: inherit; }
        select:focus { outline: 3px solid #a8d5c7; border-color: #24695b; }
        fieldset { padding: 0; border: 0; }
        .choices { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 11px; }
        .choices label { display: flex; align-items: center; gap: 9px; margin: 0; padding: 11px; border: 1px solid #d7e3df; border-radius: 4px; font-weight: 400; cursor: pointer; }
        .choices input { accent-color: #24695b; }
        .error { display: block; margin-top: 7px; color: #b42318; font-size: .86rem; }
        button { min-height: 44px; padding: 0 18px; border: 0; border-radius: 4px; background: #175b4e; color: #fff; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #10483e; }
        @media (max-width: 520px) { body { padding: 24px 12px; } .panel { padding: 19px; } h1 { font-size: 1.65rem; } .choices { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <main>
        <p class="eyebrow">INS3064 · Session 03</p>
        <h1>Your programming survey</h1>
        <p class="intro">A few quick choices help us learn what you enjoy building.</p>
        <div class="panel">
            <div class="progress" aria-label="Form progress">
                <span>01 · Register</span><span class="active">02 · Survey</span><span>03 · Summary</span>
            </div>
            <form action="survey.php" method="post">
                <div class="field">
                    <label for="language">Favorite Programming Language</label>
                    <select id="language" name="language" required aria-describedby="language-error">
                        <option value="">Choose a language</option>
                        <?php foreach ($languages as $language): ?>
                            <option value="<?php echo escapeHtml($language); ?>" <?php echo $values['language'] === $language ? 'selected' : ''; ?>><?php echo escapeHtml($language); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (isset($errors['language'])): ?><span class="error" id="language-error"><?php echo escapeHtml($errors['language']); ?></span><?php endif; ?>
                </div>
                <fieldset class="field">
                    <legend>Experience Level</legend>
                    <div class="choices">
                        <?php foreach ($experiences as $experience): ?>
                            <label><input type="radio" name="experience" value="<?php echo escapeHtml($experience); ?>" <?php echo $values['experience'] === $experience ? 'checked' : ''; ?> required> <?php echo escapeHtml($experience); ?></label>
                        <?php endforeach; ?>
                    </div>
                    <?php if (isset($errors['experience'])): ?><span class="error" id="experience-error"><?php echo escapeHtml($errors['experience']); ?></span><?php endif; ?>
                </fieldset>
                <fieldset class="field">
                    <legend>Interests <span aria-hidden="true">(choose at least one)</span></legend>
                    <div class="choices">
                        <?php foreach ($interestOptions as $interest): ?>
                            <label><input type="checkbox" name="interests[]" value="<?php echo escapeHtml($interest); ?>" <?php echo in_array($interest, $values['interests'], true) ? 'checked' : ''; ?>> <?php echo escapeHtml($interest); ?></label>
                        <?php endforeach; ?>
                    </div>
                    <?php if (isset($errors['interests'])): ?><span class="error" id="interests-error"><?php echo escapeHtml($errors['interests']); ?></span><?php endif; ?>
                </fieldset>
                <button type="submit">View my summary</button>
            </form>
        </div>
    </main>
</body>
</html>
