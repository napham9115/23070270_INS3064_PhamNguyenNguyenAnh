/*
Assignment: Homework 07 - Advanced SQL Queries
Name: [Enter your full name]
Student ID: [Enter your student ID]
Date: 2026-10-25
Database: bookstore_db
Run bookstore_db.sql first. Compatible with MySQL 8.0+.
*/
USE bookstore_db;

-- Query 1
-- Lists every book with its ISBN and author; books with multiple authors appear multiple times.
SELECT b.title AS book_title, b.isbn AS isbn, a.name AS author_name
FROM books AS b
JOIN book_authors AS ba ON ba.book_id = b.book_id
JOIN authors AS a ON a.author_id = ba.author_id
ORDER BY b.title, a.name;
/*
Expected output (sample rows; 11 rows total):
+---------------------------+---------------+---------------+
| book_title                | isbn          | author_name   |
+---------------------------+---------------+---------------+
| Algorithms Made Clear     | 9781000000003 | Sofia Rossi   |
| Designing Better Products | 9781000000005 | Lucas Meyer   |
| Foundations of Data Science | 9781000000004 | Amara Okafor |
| Foundations of Data Science | 9781000000004 | Sofia Rossi |
| Learning SQL Step by Step | 9781000000002 | Daniel Brooks |
| ...                       | ...           | ...           |
+---------------------------+---------------+---------------+
*/

-- Query 2
-- Lists orders with customer, date, book, quantity, and line total, newest orders first.
SELECT o.order_id AS order_id, c.full_name AS customer_name, o.order_date AS order_date,
       b.title AS book_title, oi.quantity AS quantity,
       oi.quantity * oi.unit_price AS line_total
FROM orders AS o
JOIN customers AS c ON c.customer_id = o.customer_id
JOIN order_items AS oi ON oi.order_id = o.order_id
JOIN books AS b ON b.book_id = oi.book_id
ORDER BY o.order_date DESC, o.order_id DESC, b.title;
/*
Expected output (sample rows; 12 rows total):
+----------+---------------+---------------------+---------------------------+----------+------------+
| order_id | customer_name | order_date          | book_title                | quantity | line_total |
+----------+---------------+---------------------+---------------------------+----------+------------+
| 6        | Alex Morgan   | 2026-09-12 08:50:00 | Designing Better Products | 1        | 21.50      |
| 6        | Alex Morgan   | 2026-09-12 08:50:00 | Learning SQL Step by Step | 1        | 24.00      |
| 5        | Mai Tran      | 2026-09-10 11:30:00 | Modern Software Patterns | 1        | 27.25      |
| ...      | ...           | ...                 | ...                       | ...      | ...        |
+----------+---------------+---------------------+---------------------------+----------+------------+
*/

-- Query 3
-- Lists each book with its publisher and every category assigned to it.
SELECT b.title AS book_title, p.name AS publisher_name, c.name AS category_name
FROM books AS b
JOIN publishers AS p ON p.publisher_id = b.publisher_id
JOIN book_categories AS bc ON bc.book_id = b.book_id
JOIN categories AS c ON c.category_id = bc.category_id
ORDER BY b.title, c.name;
/*
Expected output (sample rows; 10 rows total):
+----------------------------+----------------------+---------------+
| book_title                 | publisher_name      | category_name |
+----------------------------+----------------------+---------------+
| Algorithms Made Clear      | Maple Leaf Books    | Data Science  |
| Algorithms Made Clear      | Maple Leaf Books    | Programming   |
| Designing Better Products  | Northstar Press     | Design        |
| Foundations of Data Science| Riverbend Academic | Data Science  |
| Learning SQL Step by Step  | Open Page Publishing| Programming   |
| ...                        | ...                 | ...           |
+----------------------------+----------------------+---------------+
*/

-- Query 4
-- Calculates quantity sold and revenue for each book, ordered by revenue from highest to lowest.
SELECT b.book_id AS book_id, b.title AS book_title,
       COALESCE(SUM(oi.quantity), 0) AS total_quantity_sold,
       COALESCE(SUM(oi.quantity * oi.unit_price), 0.00) AS total_revenue
FROM books AS b
LEFT JOIN order_items AS oi ON oi.book_id = b.book_id
GROUP BY b.book_id, b.title
ORDER BY total_revenue DESC, b.title;
/*
Expected output:
+---------+-----------------------------+--------------------+---------------+
| book_id | book_title                  | total_quantity_sold| total_revenue |
+---------+-----------------------------+--------------------+---------------+
| 2       | Learning SQL Step by Step   | 3                  | 72.00         |
| 5       | Designing Better Products   | 3                  | 64.50         |
| 1       | Practical PHP for the Web   | 3                  | 55.50         |
| 6       | Modern Software Patterns    | 2                  | 54.50         |
| 7       | Small Business, Big Ideas   | 3                  | 42.00         |
| 4       | Foundations of Data Science | 1                  | 32.00         |
| 8       | The Human Side of Technology | 1                  | 19.99         |
| 3       | Algorithms Made Clear       | 1                  | 16.75         |
+---------+-----------------------------+--------------------+---------------+
*/

-- Query 5
-- Shows each customer's order count and spending, including customers with zero orders.
SELECT c.customer_id AS customer_id, c.full_name AS customer_name,
       COUNT(o.order_id) AS number_of_orders,
       COALESCE(SUM(o.total_amount), 0.00) AS total_amount_spent
FROM customers AS c
LEFT JOIN orders AS o ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.full_name
ORDER BY c.customer_id;
/*
Expected output:
+-------------+---------------+------------------+--------------------+
| customer_id | customer_name | number_of_orders | total_amount_spent |
+-------------+---------------+------------------+--------------------+
| 1           | Alex Morgan   | 2                | 112.00             |
| 2           | Linh Nguyen   | 1                | 48.75              |
| 3           | Priya Shah    | 1                | 70.25              |
| 4           | Oliver Smith  | 1                | 61.99              |
| 5           | Mai Tran      | 1                | 64.25              |
+-------------+---------------+------------------+--------------------+
*/

-- Query 6
-- Finds books priced above the average price of all books.
SELECT title AS book_title, price AS book_price
FROM books
WHERE price > (SELECT AVG(price) FROM books)
ORDER BY price DESC, title;
/*
Expected output (average price = 21.74875):
+-----------------------------+------------+
| book_title                  | book_price |
+-----------------------------+------------+
| Foundations of Data Science | 32.00      |
| Modern Software Patterns    | 27.25      |
| Learning SQL Step by Step   | 24.00      |
+-----------------------------+------------+
*/

-- Query 7
-- Finds all authors tied for the greatest total quantity sold, using a subquery rather than LIMIT.
SELECT author_sales.author_name AS author_name,
       author_sales.total_quantity_sold AS total_quantity_sold
FROM (
    SELECT a.author_id, a.name AS author_name, SUM(oi.quantity) AS total_quantity_sold
    FROM authors AS a
    JOIN book_authors AS ba ON ba.author_id = a.author_id
    JOIN order_items AS oi ON oi.book_id = ba.book_id
    GROUP BY a.author_id, a.name
) AS author_sales
WHERE author_sales.total_quantity_sold = (
    SELECT MAX(author_totals.total_quantity_sold)
    FROM (
        SELECT ba.author_id, SUM(oi.quantity) AS total_quantity_sold
        FROM book_authors AS ba
        JOIN order_items AS oi ON oi.book_id = ba.book_id
        GROUP BY ba.author_id
    ) AS author_totals
)
ORDER BY author_sales.author_name;
/*
Expected output:
+---------------+--------------------+
| author_name   | total_quantity_sold|
+---------------+--------------------+
| Daniel Brooks | 6                  |
| Lucas Meyer   | 6                  |
+---------------+--------------------+
*/

-- Query 8
-- Finds customers with more than two reviews, counting only reviews rated 3 or higher.
SELECT c.full_name AS customer_name, COUNT(r.review_id) AS qualifying_review_count
FROM customers AS c
JOIN reviews AS r ON r.customer_id = c.customer_id
WHERE r.rating >= 3
GROUP BY c.customer_id, c.full_name
HAVING COUNT(r.review_id) > 2
ORDER BY qualifying_review_count DESC, c.full_name;
/*
Expected output:
No rows returned for the supplied sample data; each customer has two reviews or fewer.
*/

-- Query 9
-- Creates a view with book, publisher, sales, and review statistics.
CREATE OR REPLACE VIEW v_book_sales_summary AS
SELECT b.title AS book_title, b.isbn AS isbn, p.name AS publisher_name,
       COALESCE(sales.total_quantity_sold, 0) AS total_quantity_sold,
       COALESCE(sales.total_revenue, 0.00) AS total_revenue,
       review_stats.average_review_rating AS average_review_rating,
       COALESCE(review_stats.number_of_reviews, 0) AS number_of_reviews
FROM books AS b
JOIN publishers AS p ON p.publisher_id = b.publisher_id
LEFT JOIN (
    SELECT book_id, SUM(quantity) AS total_quantity_sold,
           SUM(quantity * unit_price) AS total_revenue
    FROM order_items
    GROUP BY book_id
) AS sales ON sales.book_id = b.book_id
LEFT JOIN (
    SELECT book_id, AVG(rating) AS average_review_rating,
           COUNT(review_id) AS number_of_reviews
    FROM reviews
    GROUP BY book_id
) AS review_stats ON review_stats.book_id = b.book_id;

/*
Expected output (sample rows; 8 books total):
+----------------------------+---------------+----------------------+--------------------+---------------+-----------------------+------------------+
| book_title                 | isbn          | publisher_name      | total_quantity_sold| total_revenue | average_review_rating | number_of_reviews|
+----------------------------+---------------+----------------------+--------------------+---------------+-----------------------+------------------+
| Practical PHP for the Web  | 9781000000001 | Northstar Press     | 3                  | 55.50         | 4.50                  | 2                |
| Learning SQL Step by Step  | 9781000000002 | Open Page Publishing| 3                  | 72.00         | 4.00                  | 1                |
| Algorithms Made Clear      | 9781000000003 | Maple Leaf Books    | 1                  | 16.75         | 5.00                  | 2                |
| ...                        | ...           | ...                 | ...                | ...           | ...                   | ...              |
+----------------------------+---------------+----------------------+--------------------+---------------+-----------------------+------------------+
*/

-- Demonstrate that the view works.
SELECT book_title, isbn, publisher_name, total_quantity_sold, total_revenue,
       average_review_rating, number_of_reviews
FROM v_book_sales_summary
ORDER BY total_revenue DESC, book_title;

/*
-- Query 10
-- Reports every month in the current year, including months with no orders.
*/
WITH RECURSIVE months AS (
    SELECT 1 AS month_number
    UNION ALL
    SELECT month_number + 1
    FROM months
    WHERE month_number < 12
),
monthly_sales AS (
    SELECT MONTH(o.order_date) AS month_number,
           COUNT(DISTINCT o.order_id) AS number_of_orders,
           COALESCE(SUM(oi.quantity), 0) AS total_items_sold,
           COALESCE(SUM(oi.quantity * oi.unit_price), 0.00) AS total_revenue
    FROM orders AS o
    LEFT JOIN order_items AS oi ON oi.order_id = o.order_id
    WHERE YEAR(o.order_date) = YEAR(CURDATE())
    GROUP BY MONTH(o.order_date)
)
SELECT m.month_number AS month_number,
       MONTHNAME(DATE_ADD(MAKEDATE(YEAR(CURDATE()), 1),
                          INTERVAL (m.month_number - 1) MONTH)) AS month_name,
       COALESCE(ms.number_of_orders, 0) AS number_of_orders,
       COALESCE(ms.total_items_sold, 0) AS total_items_sold,
       COALESCE(ms.total_revenue, 0.00) AS total_revenue
FROM months AS m
LEFT JOIN monthly_sales AS ms ON ms.month_number = m.month_number
ORDER BY m.month_number;
/*
Expected output for the supplied sample data when run in 2026:
+--------------+------------+------------------+-----------------+---------------+
| month_number | month_name | number_of_orders | total_items_sold| total_revenue |
+--------------+------------+------------------+-----------------+---------------+
| 1            | January    | 0                | 0               | 0.00          |
| 2            | February   | 0                | 0               | 0.00          |
| ...          | ...        | ...              | ...             | ...           |
| 9            | September  | 6                | 16              | 357.24        |
| 10           | October    | 0                | 0               | 0.00          |
| ...          | ...        | ...              | ...             | ...           |
| 12           | December   | 0                | 0               | 0.00          |
+--------------+------------+------------------+-----------------+---------------+
*/
