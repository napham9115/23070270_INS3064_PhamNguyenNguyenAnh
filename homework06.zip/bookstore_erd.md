 1. Entities and Attributes
Notation: `PK` = Primary Key, `FK` = Foreign Key, `UQ` = Unique.

 authors

- `author_id` INT PK
- `name` VARCHAR(150) NOT NULL
- `biography` TEXT
- `nationality` VARCHAR(100)
- `created_at` DATETIME NOT NULL

 publishers

- `publisher_id` INT PK
- `name` VARCHAR(150) NOT NULL, UQ
- `address` VARCHAR(255)
- `website` VARCHAR(255)
- `created_at` DATETIME NOT NULL

 categories

- `category_id` INT PK
- `name` VARCHAR(100) NOT NULL, UQ
- `description` TEXT
- `parent_category_id` INT FK → categories.category_id, nullable

 books

- `book_id` INT PK
- `publisher_id` INT FK → publishers.publisher_id, NOT NULL
- `title` VARCHAR(255) NOT NULL
- `isbn` VARCHAR(20) NOT NULL, UQ
- `price` DECIMAL(10,2) NOT NULL, CHECK price > 0
- `stock` INT NOT NULL, CHECK stock >= 0
- `publication_date` DATE
- `description` TEXT
- `created_at` DATETIME NOT NULL

 book_authors

- `book_id` INT PK, FK → books.book_id
- `author_id` INT PK, FK → authors.author_id
- Composite primary key: (`book_id`, `author_id`)

 book_categories

- `book_id` INT PK, FK → books.book_id
- `category_id` INT PK, FK → categories.category_id
- Composite primary key: (`book_id`, `category_id`)

 customers

- `customer_id` INT PK
- `full_name` VARCHAR(150) NOT NULL
- `email` VARCHAR(255) NOT NULL, UQ
- `password_hash` VARCHAR(255) NOT NULL
- `phone` VARCHAR(30)
- `address` VARCHAR(255)
- `created_at` DATETIME NOT NULL

 orders

- `order_id` INT PK
- `customer_id` INT FK → customers.customer_id, NOT NULL
- `order_date` DATETIME NOT NULL
- `status` ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled') NOT NULL
- `total_amount` DECIMAL(12,2) NOT NULL, CHECK total_amount >= 0
- `shipping_address` VARCHAR(255) NOT NULL

 order_items

- `order_item_id` INT PK
- `order_id` INT FK → orders.order_id, NOT NULL
- `book_id` INT FK → books.book_id, NOT NULL
- `quantity` INT NOT NULL, CHECK quantity > 0
- `unit_price` DECIMAL(10,2) NOT NULL, CHECK unit_price > 0
- `subtotal` DECIMAL(12,2) NOT NULL, CHECK subtotal >= 0
- `UNIQUE(order_id, book_id)` — one line per book in an order

 reviews

- `review_id` INT PK
- `customer_id` INT FK → customers.customer_id, NOT NULL
- `book_id` INT FK → books.book_id, NOT NULL
- `rating` TINYINT NOT NULL, CHECK rating BETWEEN 1 AND 5
- `comment` TEXT
- `review_date` DATETIME NOT NULL
- `UNIQUE(customer_id, book_id)` — one review per customer per book

 2. Relationships and Cardinalities

```
publishers 1 ───────── N books
books      1 ───────── N book_authors N ───────── 1 authors
books      1 ───────── N book_categories N ────── 1 categories
categories 1 ───────── N categories (parent → subcategory; optional)
customers  1 ───────── N orders
orders     1 ───────── N order_items N ────────── 1 books
customers  1 ───────── N reviews N ────────────── 1 books
```

- Books ↔ Authors: M:N, implemented using `book_authors`.
- Books ↔ Categories: M:N, implemented using `book_categories`.
- Orders ↔ Books: M:N, implemented using `order_items`; each row records quantity and the unit price at the time of purchase.
- A publisher may publish many books, but each book has exactly one publisher.
- A customer may place many orders and write many reviews.
- A category may have a parent category; a parent category can contain many subcategories.

 3. 3NF Notes

- 1NF: Every field stores one value; authors and categories are not stored as comma-separated lists in `books`.
- 2NF: The junction tables use composite keys and contain no non-key attributes that depend on only part of those keys.
- 3NF: Author, publisher, category, and customer details are stored in their own tables rather than repeated in `books`, `orders`, or junction tables. Each non-key attribute depends on the key, the whole key, and nothing but the key.
- `order_items.unit_price` is a historical snapshot of the price charged at purchase time, not a lookup copy intended to track the current `books.price`.
- `orders.total_amount` and `order_items.subtotal` are stored order snapshots for this assignment; an application should calculate and validate them consistently when an order is created or updated.
