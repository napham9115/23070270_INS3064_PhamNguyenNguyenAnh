-- Online Bookstore Database
-- Compatible with MySQL 8.0.16+ (CHECK constraints are enforced from 8.0.16).

CREATE DATABASE IF NOT EXISTS bookstore_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE bookstore_db;

-- 3NF explanation:
-- 1NF: Every column contains one atomic value. Books, authors, and categories
--      are connected through junction tables instead of comma-separated lists.
-- 2NF: The composite-key junction tables contain no non-key attributes, so no
--      attribute depends on only part of a composite key.
-- 3NF: Author, publisher, category, and customer details are stored in their
--      own tables. Non-key attributes depend on the key, the whole key, and
--      nothing but the key. Order item prices and totals are purchase-time
--      snapshots; the application should calculate and validate order totals.

CREATE TABLE authors (
    author_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    biography TEXT,
    nationality VARCHAR(100),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE publishers (
    publisher_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    address VARCHAR(255),
    website VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categories (
    category_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    parent_category_id INT UNSIGNED NULL,
    CONSTRAINT fk_categories_parent
        FOREIGN KEY (parent_category_id) REFERENCES categories(category_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE customers (
    customer_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(30),
    address VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE books (
    book_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    publisher_id INT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    publication_date DATE,
    description TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_books_price CHECK (price > 0),
    CONSTRAINT chk_books_stock CHECK (stock >= 0),
    CONSTRAINT fk_books_publisher
        FOREIGN KEY (publisher_id) REFERENCES publishers(publisher_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE book_authors (
    book_id INT UNSIGNED NOT NULL,
    author_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (book_id, author_id),
    CONSTRAINT fk_book_authors_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_book_authors_author
        FOREIGN KEY (author_id) REFERENCES authors(author_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE book_categories (
    book_id INT UNSIGNED NOT NULL,
    category_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (book_id, category_id),
    CONSTRAINT fk_book_categories_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_book_categories_category
        FOREIGN KEY (category_id) REFERENCES categories(category_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (
    order_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL,
    order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled')
        NOT NULL DEFAULT 'Pending',
    total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    shipping_address VARCHAR(255) NOT NULL,
    CONSTRAINT chk_orders_total CHECK (total_amount >= 0),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (
    order_item_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    book_id INT UNSIGNED NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    CONSTRAINT uq_order_items_order_book UNIQUE (order_id, book_id),
    CONSTRAINT chk_order_items_quantity CHECK (quantity > 0),
    CONSTRAINT chk_order_items_unit_price CHECK (unit_price > 0),
    CONSTRAINT chk_order_items_subtotal CHECK (subtotal >= 0),
    CONSTRAINT chk_order_items_line_total CHECK (subtotal = quantity * unit_price),
    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_order_items_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reviews (
    review_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id INT UNSIGNED NOT NULL,
    book_id INT UNSIGNED NOT NULL,
    rating TINYINT UNSIGNED NOT NULL,
    comment TEXT,
    review_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_reviews_customer_book UNIQUE (customer_id, book_id),
    CONSTRAINT chk_reviews_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_reviews_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_book
        FOREIGN KEY (book_id) REFERENCES books(book_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data: 8 books, 6 authors, 4 publishers, 5 categories,
-- 5 customers, 6 orders, 12 order items, and 10 reviews.

INSERT INTO authors (author_id, name, biography, nationality) VALUES
(1, 'Maya Chen', 'Writes practical guides to modern software design.', 'Singaporean'),
(2, 'Daniel Brooks', 'Author of introductory programming books.', 'American'),
(3, 'Sofia Rossi', 'Writes about data, algorithms, and problem solving.', 'Italian'),
(4, 'Haruto Sato', 'Computer science educator and technical writer.', 'Japanese'),
(5, 'Amara Okafor', 'Researcher and author focused on technology and society.', 'Nigerian'),
(6, 'Lucas Meyer', 'Writes accessible books on business and design.', 'German');

INSERT INTO publishers (publisher_id, name, address, website) VALUES
(1, 'Northstar Press', '120 Market Street, Singapore', 'https://northstar.example'),
(2, 'Open Page Publishing', '45 King Street, London', 'https://openpage.example'),
(3, 'Maple Leaf Books', '80 Queen Street, Toronto', 'https://mapleleaf.example'),
(4, 'Riverbend Academic', '16 College Road, Boston', 'https://riverbend.example');

INSERT INTO categories (category_id, name, description, parent_category_id) VALUES
(1, 'Technology', 'Books about computing and digital technology.', NULL),
(2, 'Programming', 'Programming languages and software development.', 1),
(3, 'Data Science', 'Data analysis, machine learning, and statistics.', 1),
(4, 'Business', 'Business, management, and entrepreneurship.', NULL),
(5, 'Design', 'Visual, product, and user experience design.', NULL);

INSERT INTO books
    (book_id, publisher_id, title, isbn, price, stock, publication_date, description)
VALUES
(1, 1, 'Practical PHP for the Web', '9781000000001', 18.50, 42, '2024-03-12', 'A hands-on introduction to building PHP applications.'),
(2, 2, 'Learning SQL Step by Step', '9781000000002', 24.00, 30, '2023-09-05', 'Relational database concepts and SQL practice.'),
(3, 3, 'Algorithms Made Clear', '9781000000003', 16.75, 25, '2022-06-18', 'A friendly guide to core algorithms.'),
(4, 4, 'Foundations of Data Science', '9781000000004', 32.00, 18, '2025-01-20', 'Statistics and practical data analysis.'),
(5, 1, 'Designing Better Products', '9781000000005', 21.50, 20, '2024-08-14', 'Principles for thoughtful product design.'),
(6, 2, 'Modern Software Patterns', '9781000000006', 27.25, 16, '2023-11-02', 'Reusable patterns for maintainable software.'),
(7, 3, 'Small Business, Big Ideas', '9781000000007', 14.00, 35, '2021-04-09', 'A practical guide for new entrepreneurs.'),
(8, 4, 'The Human Side of Technology', '9781000000008', 19.99, 22, '2025-02-11', 'How technology shapes people and communities.');

INSERT INTO book_authors (book_id, author_id) VALUES
(1, 1),
(1, 2),
(2, 2),
(3, 3),
(4, 3),
(4, 5),
(5, 6),
(6, 1),
(6, 4),
(7, 6),
(8, 5);

INSERT INTO book_categories (book_id, category_id) VALUES
(1, 2),
(2, 2),
(3, 2),
(3, 3),
(4, 3),
(5, 5),
(6, 2),
(6, 1),
(7, 4),
(8, 1);

INSERT INTO customers
    (customer_id, full_name, email, password_hash, phone, address)
VALUES
(1, 'Alex Morgan', 'alex.morgan@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', '+1-555-0101', '12 Cedar Lane, Boston'),
(2, 'Linh Nguyen', 'linh.nguyen@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', '+84-901-000-002', '28 Hoang Dieu, Hanoi'),
(3, 'Priya Shah', 'priya.shah@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', '+1-555-0103', '7 Pine Avenue, Toronto'),
(4, 'Oliver Smith', 'oliver.smith@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', '+44-7700-900004', '19 Park Road, London'),
(5, 'Mai Tran', 'mai.tran@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', '+84-902-000-005', '5 Nguyen Trai, Hanoi');

INSERT INTO orders
    (order_id, customer_id, order_date, status, total_amount, shipping_address)
VALUES
(1, 1, '2026-09-01 10:15:00', 'Delivered', 66.50, '12 Cedar Lane, Boston'),
(2, 2, '2026-09-03 14:20:00', 'Shipped', 48.75, '28 Hoang Dieu, Hanoi'),
(3, 3, '2026-09-05 09:05:00', 'Processing', 70.25, '7 Pine Avenue, Toronto'),
(4, 4, '2026-09-08 16:40:00', 'Delivered', 61.99, '19 Park Road, London'),
(5, 5, '2026-09-10 11:30:00', 'Pending', 64.25, '5 Nguyen Trai, Hanoi'),
(6, 1, '2026-09-12 08:50:00', 'Processing', 45.50, '12 Cedar Lane, Boston');

INSERT INTO order_items
    (order_item_id, order_id, book_id, quantity, unit_price, subtotal)
VALUES
(1, 1, 1, 1, 18.50, 18.50),
(2, 1, 2, 2, 24.00, 48.00),
(3, 2, 3, 1, 16.75, 16.75),
(4, 2, 4, 1, 32.00, 32.00),
(5, 3, 5, 2, 21.50, 43.00),
(6, 3, 6, 1, 27.25, 27.25),
(7, 4, 7, 3, 14.00, 42.00),
(8, 4, 8, 1, 19.99, 19.99),
(9, 5, 1, 2, 18.50, 37.00),
(10, 5, 6, 1, 27.25, 27.25),
(11, 6, 2, 1, 24.00, 24.00),
(12, 6, 5, 1, 21.50, 21.50);

INSERT INTO reviews
    (review_id, customer_id, book_id, rating, comment, review_date)
VALUES
(1, 1, 1, 5, 'Clear explanations and useful examples.', '2026-09-15 12:00:00'),
(2, 1, 2, 4, 'A solid introduction to SQL.', '2026-09-15 12:10:00'),
(3, 2, 3, 5, 'The examples made the algorithms easy to follow.', '2026-09-16 09:30:00'),
(4, 2, 4, 4, 'Helpful overview with practical ideas.', '2026-09-16 09:45:00'),
(5, 3, 5, 5, 'Thoughtful and easy to apply.', '2026-09-17 15:20:00'),
(6, 3, 6, 4, 'A useful reference for software teams.', '2026-09-17 15:35:00'),
(7, 4, 7, 3, 'A quick read with a few good suggestions.', '2026-09-18 11:05:00'),
(8, 4, 8, 5, 'An engaging perspective on technology.', '2026-09-18 11:20:00'),
(9, 5, 1, 4, 'Good examples for someone starting out.', '2026-09-19 13:00:00'),
(10, 5, 3, 5, 'Concise and approachable.', '2026-09-19 13:15:00');
