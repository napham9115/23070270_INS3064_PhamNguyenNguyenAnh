/*
 * Name: Pham Nguyen Nguyen Anh
 * Student ID: 23070270
 * Assignment: INS3064 - Homework 05
 * Date: 11/10/2026
 */

USE university_db;

/*
 * Query 1: List All Students
 * Description: Retrieves all columns from the students table.
 * Expected Output: All 10 students and their information.
 */
SELECT *
FROM students;

/*
 * Expected Output:
 * +----+------------+---------------------+--------------------------+--------+---------------+------+--------------+---------------+
 * | id | student_code | full_name         | email                    | gender | date_of_birth | gpa  | enrolled_date| department_code|
 * +----+------------+---------------------+--------------------------+--------+---------------+------+--------------+---------------+
 * | 1  | SV2024001  | Nguyễn Minh Khôi    | khoi.nm@student.edu.vn    | Male   | 2005-03-14    | 3.45 | 2024-09-01   | CS            |
 * | 2  | SV2024002  | Trần Thị Thu Hằng   | hang.ttt@student.edu.vn   | Female | 2005-07-22    | 3.80 | 2024-09-01   | CS            |
 * | 3  | SV2024003  | Lê Hoàng Nam        | nam.lh@student.edu.vn     | Male   | 2005-11-05    | 2.90 | 2024-09-01   | MATH          |
 * | 4  | SV2024004  | Phạm Ngọc Anh       | anh.pn@student.edu.vn     | Female | 2005-01-30    | 3.60 | 2024-09-01   | ECON          |
 * | 5  | SV2024005  | Vũ Thị Hương        | huong.vt@student.edu.vn   | Female | 2005-09-18    | 3.25 | 2024-09-01   | ENG           |
 * | 6  | SV2024006  | Đặng Quốc Bảo       | bao.dq@student.edu.vn     | Male   | 2004-12-02    | 2.75 | 2024-09-01   | PHY           |
 * | 7  | SV2025001  | Bùi Thanh Tùng      | tung.bt@student.edu.vn    | Male   | 2006-04-09    | 3.10 | 2025-09-01   | CS            |
 * | 8  | SV2025002  | Hoàng Mỹ Linh       | linh.hm@student.edu.vn    | Female | 2006-06-25    | 3.90 | 2025-09-01   | MATH          |
 * | 9  | SV2025003  | Ngô Gia Huy         | huy.ng@student.edu.vn     | Male   | 2006-02-17    | 2.50 | 2025-09-01   | ECON          |
 * | 10 | SV2025004  | Đinh Khánh Vy       | vy.dk@student.edu.vn      | Other  | 2006-08-11    | 3.35 | 2025-09-01   | ENG           |
 * +----+------------+---------------------+--------------------------+--------+---------------+------+--------------+---------------+
 * (10 rows)
 */

/*
 * Query 2: Students with GPA Above 3.5
 * Description: Finds students whose GPA is greater than 3.50.
 * Expected Output: 3 students.
 */
SELECT student_code, full_name, gpa
FROM students
WHERE gpa > 3.50
ORDER BY gpa DESC;

/*
 * Expected Output:
 * +------------+-------------------+------+
 * | student_code | full_name       | gpa  |
 * +------------+-------------------+------+
 * | SV2025002  | Hoàng Mỹ Linh     | 3.90 |
 * | SV2024002  | Trần Thị Thu Hằng | 3.80 |
 * | SV2024004  | Phạm Ngọc Anh     | 3.60 |
 * +------------+-------------------+------+
 * (3 rows)
 */

/*
 * Query 3: Courses Matching Multiple Conditions
 * Description: Uses AND and OR to find courses with at least 3 credits
 *              in Computer Science or at least 4 credits in Mathematics.
 * Expected Output: 4 courses.
 */
SELECT course_code, course_title, credits, department_code
FROM courses
WHERE (department_code = 'CS' AND credits >= 3)
   OR (department_code = 'MATH' AND credits >= 4)
ORDER BY course_code;

/*
 * Expected Output:
 * +-------------+-------------------------------+---------+-----------------+
 * | course_code | course_title                  | credits | department_code |
 * +-------------+-------------------------------+---------+-----------------+
 * | CS101       | Introduction to Programming   | 3       | CS              |
 * | CS201       | Database Systems              | 3       | CS              |
 * | CS301       | Data Mining                   | 4       | CS              |
 * | MATH101     | Calculus I                    | 4       | MATH            |
 * +-------------+-------------------------------+---------+-----------------+
 * (4 rows)
 */

/*
 * Query 4: Sort Students by Student Code
 * Description: Displays students in ascending order of student_code.
 * Expected Output: All 10 students sorted by student code.
 */
SELECT student_code, full_name, gpa
FROM students
ORDER BY student_code ASC;

/*
 * Expected Output:
 * +------------+---------------------+------+
 * | student_code | full_name         | gpa  |
 * +------------+---------------------+------+
 * | SV2024001  | Nguyễn Minh Khôi    | 3.45 |
 * | SV2024002  | Trần Thị Thu Hằng   | 3.80 |
 * | SV2024003  | Lê Hoàng Nam        | 2.90 |
 * | SV2024004  | Phạm Ngọc Anh       | 3.60 |
 * | SV2024005  | Vũ Thị Hương        | 3.25 |
 * | SV2024006  | Đặng Quốc Bảo       | 2.75 |
 * | SV2025001  | Bùi Thanh Tùng      | 3.10 |
 * | SV2025002  | Hoàng Mỹ Linh       | 3.90 |
 * | SV2025003  | Ngô Gia Huy         | 2.50 |
 * | SV2025004  | Đinh Khánh Vy       | 3.35 |
 * +------------+---------------------+------+
 * (10 rows)
 */

/*
 * Query 5: Top 3 Highest Grades
 * Description: Returns the three highest non-NULL grades in enrollments.
 * Expected Output: 3 enrollment records.
 */
SELECT student_code, course_code, semester_name, grade
FROM enrollments
WHERE grade IS NOT NULL
ORDER BY grade DESC, id ASC
LIMIT 3;

/*
 * Expected Output:
 * +------------+-------------+-------------+------+
 * | student_code | course_code | semester_name | grade |
 * +------------+-------------+-------------+------+
 * | SV2024002  | CS101       | Fall 2024   | 4.00 |
 * | SV2025002  | MATH201     | Fall 2025   | 4.00 |
 * | SV2024002  | CS201       | Spring 2025 | 3.80 |
 * +------------+-------------+-------------+------+
 * (3 rows)
 */

/*
 * Query 6: Search Courses by Title
 * Description: Finds course titles containing the word "Introduction".
 * Expected Output: 2 courses.
 */
SELECT course_code, course_title
FROM courses
WHERE course_title LIKE '%Introduction%'
ORDER BY course_code;

/*
 * Expected Output:
 * +-------------+-------------------------------+
 * | course_code | course_title                  |
 * +-------------+-------------------------------+
 * | CS101       | Introduction to Programming   |
 * | ENG101      | Introduction to Linguistics   |
 * +-------------+-------------------------------+
 * (2 rows)
 */

/*
 * Query 7: Count Students by Department
 * Description: Counts students in each department using COUNT and GROUP BY.
 * Expected Output: 5 departments and their student counts.
 */
SELECT d.department_name AS department_name,
       COUNT(s.id) AS student_count
FROM departments d
LEFT JOIN students s
    ON s.department_code = d.department_code
GROUP BY d.department_code, d.department_name
ORDER BY d.department_code;

/*
 * Expected Output:
 * +---------------------+---------------+
 * | department_name     | student_count |
 * +---------------------+---------------+
 * | Computer Science    | 3             |
 * | Economics            | 2             |
 * | English Linguistics | 2             |
 * | Mathematics          | 2             |
 * | Physics              | 1             |
 * +---------------------+---------------+
 * (5 rows)
 */

/*
 * Query 8: Departments with More Than One Course
 * Description: Groups courses by department and uses HAVING to show
 *              departments offering more than one course.
 * Expected Output: 2 departments.
 */
SELECT d.department_name AS department_name,
       COUNT(c.id) AS course_count
FROM departments d
JOIN courses c
    ON c.department_code = d.department_code
GROUP BY d.department_code, d.department_name
HAVING COUNT(c.id) > 1
ORDER BY d.department_code;

/*
 * Expected Output:
 * +---------------------+--------------+
 * | department_name     | course_count |
 * +---------------------+--------------+
 * | Computer Science    | 3            |
 * | Mathematics          | 2            |
 * +---------------------+--------------+
 * (2 rows)
 */

/*
 * Query 9: Courses and Their Instructors
 * Description: Joins courses and instructors using instructor_code.
 * Expected Output: 8 courses with their instructor names.
 */
SELECT c.course_code,
       c.course_title,
       i.full_name AS instructor_name
FROM courses c
JOIN instructors i
    ON c.instructor_code = i.instructor_code
ORDER BY c.course_code;

/*
 * Expected Output:
 * +-------------+-------------------------------+-----------------+
 * | course_code | course_title                  | instructor_name |
 * +-------------+-------------------------------+-----------------+
 * | CS101       | Introduction to Programming   | Nguyễn Văn Hùng |
 * | CS201       | Database Systems              | Đỗ Thị Lan      |
 * | CS301       | Data Mining                   | Nguyễn Văn Hùng |
 * | ECON101     | Microeconomics                | Lê Quang Minh   |
 * | ENG101      | Introduction to Linguistics   | Phạm Thu Hà     |
 * | MATH101     | Calculus I                    | Trần Thị Mai    |
 * | MATH201     | Linear Algebra                | Trần Thị Mai    |
 * | PHY101      | General Physics               | Hoàng Đức Anh   |
 * +-------------+-------------------------------+-----------------+
 * (8 rows)
 */

/*
 * Query 10: Enrollment Details
 * Description: Joins enrollments, students, courses, and semesters to show
 *              each student's course, semester, and grade.
 * Expected Output: 19 enrollment records, including NULL grades.
 */
SELECT e.id AS enrollment_id,
       s.full_name AS student_name,
       c.course_title,
       sem.semester_name,
       e.grade
FROM enrollments e
JOIN students s
    ON e.student_code = s.student_code
JOIN courses c
    ON e.course_code = c.course_code
JOIN semesters sem
    ON e.semester_name = sem.semester_name
ORDER BY e.id;

/*
 * Expected Output:
 * +---------------+-------------------+-------------------------------+-------------+------+
 * | enrollment_id | student_name      | course_title                  | semester_name | grade |
 * +---------------+-------------------+-------------------------------+-------------+------+
 * | 1             | Nguyễn Minh Khôi  | Introduction to Programming   | Fall 2024   | 3.50 |
 * | 2             | Nguyễn Minh Khôi  | Calculus I                    | Fall 2024   | 3.00 |
 * | 3             | Nguyễn Minh Khôi  | Database Systems              | Spring 2025 | 3.50 |
 * | 4             | Trần Thị Thu Hằng | Introduction to Programming   | Fall 2024   | 4.00 |
 * | 5             | Trần Thị Thu Hằng | Database Systems              | Spring 2025 | 3.80 |
 * | 6             | Trần Thị Thu Hằng | Data Mining                   | Fall 2025   | 3.70 |
 * | 7             | Lê Hoàng Nam      | Calculus I                    | Fall 2024   | 2.50 |
 * | 8             | Lê Hoàng Nam      | Linear Algebra                | Spring 2025 | 3.00 |
 * | 9             | Phạm Ngọc Anh     | Microeconomics                | Fall 2024   | 3.50 |
 * | 10            | Phạm Ngọc Anh     | Calculus I                    | Spring 2025 | 3.20 |
 * | 11            | Vũ Thị Hương      | Introduction to Linguistics   | Fall 2024   | 3.30 |
 * | 12            | Vũ Thị Hương      | Introduction to Linguistics   | Fall 2025   | NULL |
 * | 13            | Đặng Quốc Bảo     | General Physics               | Spring 2025 | 2.00 |
 * | 14            | Bùi Thanh Tùng    | Introduction to Programming   | Fall 2025   | 3.00 |
 * | 15            | Hoàng Mỹ Linh     | Linear Algebra                | Fall 2025   | 4.00 |
 * | 16            | Ngô Gia Huy       | Microeconomics                | Spring 2026 | 2.50 |
 * | 17            | Đinh Khánh Vy     | Introduction to Linguistics   | Spring 2026 | 3.40 |
 * | 18            | Nguyễn Minh Khôi  | Data Mining                   | Fall 2026   | NULL |
 * | 19            | Bùi Thanh Tùng    | Database Systems              | Fall 2026   | NULL |
 * +---------------+-------------------+-------------------------------+-------------+------+
 * (19 rows)
 */