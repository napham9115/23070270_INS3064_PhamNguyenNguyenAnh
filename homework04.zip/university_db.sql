-- Name        : Pham Nguyen Nguyen Anh
-- Student ID  : 23070270
-- Assignment  : University Course Registration System
-- Date        : 04/10/2026

-- 0. CLEAN UP OLD DATABASE (student_management)
DROP TABLE IF EXISTS student_management.classes;
DROP TABLE IF EXISTS student_management.students;
DROP DATABASE IF EXISTS student_management;

-- 1. CREATE NEW DATABASE (idempotent)
CREATE DATABASE university_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE university_db;

-- 2. TABLES
-- departments: 
CREATE TABLE departments (
    id              INT AUTO_INCREMENT PRIMARY KEY,                -- surrogate primary key
    department_code VARCHAR(10)  NOT NULL UNIQUE,                  -- unique code, referenced by other tables
    department_name VARCHAR(100) NOT NULL UNIQUE,                  -- full unique name
    description     TEXT NULL,                                     -- optional description
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP    -- creation time
) ENGINE=InnoDB;

-- semesters:
CREATE TABLE semesters (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    semester_name VARCHAR(30) NOT NULL UNIQUE,                     -- e.g. 'Fall 2024', referenced by enrollments
    academic_year VARCHAR(9)  NOT NULL,                            -- e.g. '2024-2025'
    start_date    DATE NOT NULL,
    end_date      DATE NOT NULL,
    CONSTRAINT chk_semester_dates CHECK (end_date > start_date)    -- end must be after start
) ENGINE=InnoDB;

-- instructors: teaching staff, each belongs to one department (1:N)
CREATE TABLE instructors (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    instructor_code VARCHAR(10)  NOT NULL UNIQUE,                  -- unique code, referenced by courses
    full_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(100) NOT NULL UNIQUE,
    phone           VARCHAR(15)  NULL,
    hire_date       DATE NOT NULL,
    department_code VARCHAR(10)  NOT NULL,                         -- FK -> departments.department_code
    CONSTRAINT fk_instructors_department FOREIGN KEY (department_code)
        REFERENCES departments(department_code)
        ON DELETE RESTRICT                                         -- cannot delete a department that still has instructors
        ON UPDATE CASCADE                                          -- code changes propagate
) ENGINE=InnoDB;

-- students: each student has one major department (1:N)
CREATE TABLE students (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    student_code    VARCHAR(15)  NOT NULL UNIQUE,                  -- unique code, referenced by enrollments
    full_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(100) NOT NULL UNIQUE,
    gender          ENUM('Male','Female','Other') NOT NULL DEFAULT 'Other',
    date_of_birth   DATE NOT NULL,
    gpa             DECIMAL(3,2) NOT NULL DEFAULT 0.00,            -- 0.00 - 4.00
    enrolled_date   DATE NOT NULL,
    department_code VARCHAR(10)  NOT NULL,                         -- FK -> departments.department_code (major)
    CONSTRAINT chk_students_gpa CHECK (gpa BETWEEN 0.00 AND 4.00),
    CONSTRAINT fk_students_department FOREIGN KEY (department_code)
        REFERENCES departments(department_code)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- courses: each course belongs to a department and is taught by one instructor
CREATE TABLE courses (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    course_code     VARCHAR(10)  NOT NULL UNIQUE,                  -- unique code, referenced by enrollments
    course_title    VARCHAR(150) NOT NULL,
    description     TEXT NULL,
    credits         TINYINT NOT NULL DEFAULT 3,
    department_code VARCHAR(10)  NOT NULL,                         -- FK -> departments.department_code
    instructor_code VARCHAR(10)  NOT NULL,                         -- FK -> instructors.instructor_code
    CONSTRAINT chk_courses_credits CHECK (credits BETWEEN 1 AND 6),
    CONSTRAINT fk_courses_department FOREIGN KEY (department_code)
        REFERENCES departments(department_code)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_courses_instructor FOREIGN KEY (instructor_code)
        REFERENCES instructors(instructor_code)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- enrollments: junction table for the M:N relationship students <-> courses per semester
CREATE TABLE enrollments (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_code    VARCHAR(15) NOT NULL,                          -- FK -> students.student_code
    course_code     VARCHAR(10) NOT NULL,                          -- FK -> courses.course_code
    semester_name   VARCHAR(30) NOT NULL,                          -- FK -> semesters.semester_name
    enrollment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    grade           DECIMAL(3,2) NULL,                             -- optional numeric grade (0.00 - 4.00)
    grade_letter    ENUM('A','B+','B','C+','C','D','F') NULL,      -- optional letter grade
    CONSTRAINT chk_enrollments_grade CHECK (grade IS NULL OR grade BETWEEN 0.00 AND 4.00),
    CONSTRAINT unique_enrollment UNIQUE (student_code, course_code, semester_name),  -- no duplicate enrollment
    CONSTRAINT fk_enrollments_student FOREIGN KEY (student_code)
        REFERENCES students(student_code)
        ON DELETE CASCADE                                          -- delete enrollments with the student
        ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_course FOREIGN KEY (course_code)
        REFERENCES courses(course_code)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_enrollments_semester FOREIGN KEY (semester_name)
        REFERENCES semesters(semester_name)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 3. SAMPLE DATA

INSERT INTO departments (department_code, department_name, description) VALUES
('CS',  'Computer Science',    'Programming, databases, data science and AI'),
('MATH','Mathematics',         'Pure and applied mathematics, statistics'),
('ECON','Economics',           'Micro/macroeconomics, econometrics'),
('ENG', 'English Linguistics', 'Linguistics, discourse analysis, translation'),
('PHY', 'Physics',             'General and applied physics');

INSERT INTO semesters (semester_name, academic_year, start_date, end_date) VALUES
('Fall 2024',   '2024-2025', '2024-09-05', '2025-01-10'),
('Spring 2025', '2024-2025', '2025-02-10', '2025-06-15'),
('Fall 2025',   '2025-2026', '2025-09-05', '2026-01-10'),
('Spring 2026', '2025-2026', '2026-02-09', '2026-06-14'),
('Fall 2026',   '2026-2027', '2026-09-07', '2027-01-09');

INSERT INTO instructors (instructor_code, full_name, email, phone, hire_date, department_code) VALUES
('GV001', 'Nguyễn Văn Hùng', 'hung.nguyen@university.edu.vn', '0912345678', '2015-08-20', 'CS'),
('GV002', 'Đỗ Thị Lan',      'lan.do@university.edu.vn',      '0923456789', '2018-03-12', 'CS'),
('GV003', 'Trần Thị Mai',    'mai.tran@university.edu.vn',    '0934567890', '2012-09-01', 'MATH'),
('GV004', 'Lê Quang Minh',   'minh.le@university.edu.vn',     '0945678901', '2016-01-15', 'ECON'),
('GV005', 'Phạm Thu Hà',     'ha.pham@university.edu.vn',     '0956789012', '2019-07-08', 'ENG'),
('GV006', 'Hoàng Đức Anh',   'anh.hoang@university.edu.vn',   NULL,         '2014-10-30', 'PHY');

INSERT INTO students (student_code, full_name, email, gender, date_of_birth, gpa, enrolled_date, department_code) VALUES
('SV2024001', 'Nguyễn Minh Khôi',  'khoi.nm@student.edu.vn',  'Male',   '2005-03-14', 3.45, '2024-09-01', 'CS'),
('SV2024002', 'Trần Thị Thu Hằng', 'hang.ttt@student.edu.vn','Female', '2005-07-22', 3.80, '2024-09-01', 'CS'),
('SV2024003', 'Lê Hoàng Nam',      'nam.lh@student.edu.vn',   'Male',   '2005-11-05', 2.90, '2024-09-01', 'MATH'),
('SV2024004', 'Phạm Ngọc Anh',     'anh.pn@student.edu.vn',   'Female', '2005-01-30', 3.60, '2024-09-01', 'ECON'),
('SV2024005', 'Vũ Thị Hương',      'huong.vt@student.edu.vn', 'Female', '2005-09-18', 3.25, '2024-09-01', 'ENG'),
('SV2024006', 'Đặng Quốc Bảo',     'bao.dq@student.edu.vn',   'Male',   '2004-12-02', 2.75, '2024-09-01', 'PHY'),
('SV2025001', 'Bùi Thanh Tùng',    'tung.bt@student.edu.vn',  'Male',   '2006-04-09', 3.10, '2025-09-01', 'CS'),
('SV2025002', 'Hoàng Mỹ Linh',     'linh.hm@student.edu.vn',  'Female', '2006-06-25', 3.90, '2025-09-01', 'MATH'),
('SV2025003', 'Ngô Gia Huy',       'huy.ng@student.edu.vn',   'Male',   '2006-02-17', 2.50, '2025-09-01', 'ECON'),
('SV2025004', 'Đinh Khánh Vy',     'vy.dk@student.edu.vn',    'Other',  '2006-08-11', 3.35, '2025-09-01', 'ENG');

INSERT INTO courses (course_code, course_title, description, credits, department_code, instructor_code) VALUES
('CS101',   'Introduction to Programming', 'Python fundamentals and problem solving',       3, 'CS',   'GV001'),
('CS201',   'Database Systems',            'Relational model, SQL, normalization',          3, 'CS',   'GV002'),
('CS301',   'Data Mining',                 'Classification, clustering, association rules', 4, 'CS',   'GV001'),
('MATH101', 'Calculus I',                  'Limits, derivatives and integrals',             4, 'MATH', 'GV003'),
('MATH201', 'Linear Algebra',              'Matrices, vector spaces, eigenvalues',          3, 'MATH', 'GV003'),
('ECON101', 'Microeconomics',              'Supply, demand and market structures',          3, 'ECON', 'GV004'),
('ENG101',  'Introduction to Linguistics', 'Phonetics, syntax, semantics and pragmatics',   3, 'ENG',  'GV005'),
('PHY101',  'General Physics',             'Mechanics, thermodynamics and waves',           4, 'PHY',  'GV006');

INSERT INTO enrollments (student_code, course_code, semester_name, enrollment_date, grade, grade_letter) VALUES
('SV2024001', 'CS101',   'Fall 2024',   '2024-09-02 08:00:00', 3.50, 'A'),
('SV2024001', 'MATH101', 'Fall 2024',   '2024-09-02 08:05:00', 3.00, 'B'),
('SV2024001', 'CS201',   'Spring 2025', '2025-02-11 09:00:00', 3.50, 'A'),
('SV2024002', 'CS101',   'Fall 2024',   '2024-09-02 08:10:00', 4.00, 'A'),
('SV2024002', 'CS201',   'Spring 2025', '2025-02-11 09:10:00', 3.80, 'A'),
('SV2024002', 'CS301',   'Fall 2025',   '2025-09-06 10:00:00', 3.70, 'A'),
('SV2024003', 'MATH101', 'Fall 2024',   '2024-09-03 07:30:00', 2.50, 'C+'),
('SV2024003', 'MATH201', 'Spring 2025', '2025-02-12 07:45:00', 3.00, 'B'),
('SV2024004', 'ECON101', 'Fall 2024',   '2024-09-03 13:00:00', 3.50, 'A'),
('SV2024004', 'MATH101', 'Spring 2025', '2025-02-12 13:15:00', 3.20, 'B+'),
('SV2024005', 'ENG101',  'Fall 2024',   '2024-09-04 14:00:00', 3.30, 'B+'),
('SV2024005', 'ENG101',  'Fall 2025',   '2025-09-07 14:10:00', NULL, NULL),
('SV2024006', 'PHY101',  'Spring 2025', '2025-02-13 08:30:00', 2.00, 'C'),
('SV2025001', 'CS101',   'Fall 2025',   '2025-09-06 08:20:00', 3.00, 'B'),
('SV2025002', 'MATH201', 'Fall 2025',   '2025-09-06 09:30:00', 4.00, 'A'),
('SV2025003', 'ECON101', 'Spring 2026', '2026-02-10 13:30:00', 2.50, 'C+'),
('SV2025004', 'ENG101',  'Spring 2026', '2026-02-10 14:00:00', 3.40, 'B+'),
('SV2024001', 'CS301',   'Fall 2026',   '2026-09-08 08:00:00', NULL, NULL),
('SV2025001', 'CS201',   'Fall 2026',   '2026-09-08 08:30:00', NULL, NULL);
