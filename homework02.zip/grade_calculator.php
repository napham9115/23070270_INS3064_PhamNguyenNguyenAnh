<?php
$students = [
    ['name' => 'Nguyen Minh Anh', 'scores' => [8.5, 9.2, 7.8, 9.0]],
    ['name' => 'Tran Quoc Bao', 'scores' => [7.0, 6.5, 8.0, 7.2]],
    ['name' => 'Le Thu Ha', 'scores' => [6.3, 6.3, 6.3, 6.3]],
    ['name' => 'Pham Gia Huy', 'scores' => [1.0, 2.0, 1.0, 2.0]],
    ['name' => 'Vo Khanh Linh', 'scores' => [10.0, 10.0, 10.0, 10.0]],
    ['name' => 'Do Thanh Nam', 'scores' => [8.9, 9.1, 9.0, 9.0]],
];

function calculateAverage(array $scores): float
{
    $scoreCount = count($scores);

    if ($scoreCount === 0) {
        return 0.0;
    }

    $total = 0;
    for ($index = 0; $index < $scoreCount; $index++) {
        $total += $scores[$index];
    }

    return round($total / $scoreCount, 1);
}

function assignGrade(float $average): string
{
    if ($average >= 9) {
        return 'A';
    } elseif ($average >= 8) {
        return 'B';
    } elseif ($average >= 7) {
        return 'C';
    } elseif ($average >= 6) {
        return 'D';
    } else {
        return 'F';
    }
}

function gradeClass(string $grade): string
{
    return 'grade-' . strtolower($grade);
}

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$results = [];
foreach ($students as $originalIndex => $student) {
    $scores = $student['scores'];
    $average = calculateAverage($scores);

    $results[] = [
        'name' => $student['name'],
        'scores' => $scores,
        'average' => $average,
        'highest' => count($scores) > 0 ? max($scores) : 0,
        'lowest' => count($scores) > 0 ? min($scores) : 0,
        'grade' => assignGrade($average),
        'original_index' => $originalIndex,
    ];
}

usort($results, function (array $firstStudent, array $secondStudent): int {
    if ($firstStudent['average'] === $secondStudent['average']) {
        return $firstStudent['original_index'] <=> $secondStudent['original_index'];
    }

    return $secondStudent['average'] <=> $firstStudent['average'];
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grade Calculator</title>
    <style>
        :root {
            color-scheme: light;
            font-family: Arial, sans-serif;
            background: #f4f7f6;
            color: #202b2a;
        }

        body {
            margin: 0;
            padding: 32px 18px;
        }

        main {
            max-width: 1000px;
            margin: 0 auto;
        }

        h1 {
            margin: 0 0 8px;
            color: #145a50;
        }

        .subtitle {
            margin: 0 0 24px;
            color: #52615e;
        }

        .table-wrap {
            overflow-x: auto;
            border: 1px solid #d5dfdc;
            border-radius: 6px;
            background: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th,
        td {
            padding: 12px 14px;
            border-bottom: 1px solid #e3e9e7;
            white-space: nowrap;
        }

        th {
            background: #145a50;
            color: #fff;
            font-size: 0.9rem;
        }

        tbody tr:nth-child(even) {
            background: #f7faf9;
        }

        tbody tr:last-child td {
            border-bottom: 0;
        }

        .numeric {
            text-align: center;
            font-variant-numeric: tabular-nums;
        }

        .grade {
            font-weight: 700;
            text-align: center;
        }

        .grade-a { color: #137333; }
        .grade-b { color: #1769aa; }
        .grade-c { color: #8a6100; }
        .grade-d { color: #b54708; }
        .grade-f { color: #b42318; }

        @media (max-width: 600px) {
            body {
                padding: 24px 12px;
            }

            h1 {
                font-size: 1.5rem;
            }

            th,
            td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <main>
        <h1>Student Grade Calculator</h1>
        <p class="subtitle">Scores are out of 10. Grades: A ≥ 9, B ≥ 8, C ≥ 7, D ≥ 6, otherwise F.</p>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th scope="col">Rank</th>
                        <th scope="col">Name</th>
                        <th scope="col">Scores (/10)</th>
                        <th scope="col">Average (/10)</th>
                        <th scope="col">Highest (/10)</th>
                        <th scope="col">Lowest (/10)</th>
                        <th scope="col">Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $rank => $student): ?>
                        <tr>
                            <td class="numeric"><?php echo $rank + 1; ?></td>
                            <td><?php echo escapeHtml($student['name']); ?></td>
                            <td><?php echo escapeHtml(implode(', ', $student['scores'])); ?></td>
                            <td class="numeric"><?php echo number_format($student['average'], 1); ?></td>
                            <td class="numeric"><?php echo number_format($student['highest'], 1); ?></td>
                            <td class="numeric"><?php echo number_format($student['lowest'], 1); ?></td>
                            <td class="grade <?php echo escapeHtml(gradeClass($student['grade'])); ?>">
                                <?php echo escapeHtml($student['grade']); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
